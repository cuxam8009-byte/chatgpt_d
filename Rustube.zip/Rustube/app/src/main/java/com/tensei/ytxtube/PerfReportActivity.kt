package com.tensei.ytxtube

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Bản đo hiệu năng": shows what [Perf] collected and lets the user copy or share it. */
class PerfReportActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YtxTubeTheme { PerfReportScreen() } }
    }
}

@Composable
private fun PerfReportScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = MaterialTheme.colorScheme
    var report by remember { mutableStateOf(Perf.buildReport(context)) }
    var overlayOn by remember { mutableStateOf(Perf.overlayEnabled(context)) }
    var benchRunning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(c.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "Bản đo Rustube",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = c.onBackground,
        )
        Text(
            text = "Cách đo: bấm “Đặt lại số liệu”, quay về app và làm đúng MỘT việc khoảng 15 giây " +
                "(ví dụ cuộn trang chủ), mở lại màn hình này, bấm “Làm mới”, rồi “Sao chép” và dán " +
                "cho Claude kèm tên việc vừa làm. Đo mở app: vuốt tắt app, mở lại, vào đây.",
            fontSize = 13.sp,
            lineHeight = 18.sp,
            color = c.onSurfaceVariant,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { report = Perf.buildReport(context) }) { Text("Làm mới") }
            OutlinedButton(onClick = {
                Perf.reset()
                report = Perf.buildReport(context)
            }) { Text("Đặt lại số liệu") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                copyReport(context, report)
                Toast.makeText(context, "Đã sao chép bản đo", Toast.LENGTH_SHORT).show()
            }) { Text("Sao chép") }
            OutlinedButton(onClick = { shareReport(context, report) }) { Text("Chia sẻ") }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Hiện FPS trên màn hình khi dùng app",
                modifier = Modifier.weight(1f),
                color = c.onBackground,
                fontSize = 14.sp,
            )
            Switch(
                checked = overlayOn,
                onCheckedChange = {
                    overlayOn = it
                    Perf.setOverlayEnabled(context, it)
                },
            )
        }

        Button(
            enabled = !benchRunning,
            onClick = {
                benchRunning = true
                scope.launch {
                    val result = withContext(Dispatchers.Default) { Perf.runJsonBench(context) }
                    Perf.jsonBench = result
                    report = Perf.buildReport(context)
                    benchRunning = false
                }
            },
        ) { Text(if (benchRunning) "Đang chạy…" else "Chạy thử JSON (khoảng vài giây)") }

        Text(
            text = report,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            color = c.onBackground,
        )
    }
}

private fun copyReport(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Rustube bản đo", text))
}

private fun shareReport(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND)
    send.type = "text/plain"
    send.putExtra(Intent.EXTRA_TEXT, text)
    context.startActivity(Intent.createChooser(send, "Gửi bản đo"))
}
